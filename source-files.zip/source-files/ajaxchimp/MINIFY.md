Here for easy reference

```
npm install uglify-js -g
```

```js
uglifyjs jquery.ajaxchimp.js -o jquery.ajaxchimp.min.js
uglifyjs jquery.ajaxchimp.langs.js -o jquery.ajaxchimp.langs.min.js
```